function [] = plotInterface(psi,alpha,mx,my,x,y,X,Y,dx,dy,str)
[I, J] = find(alpha<1e19);
x1 = X(alpha<1e19);
y1 = Y(alpha<1e19);
m1 = mx(alpha<1e19);
m2 = my(alpha<1e19);
m1(m1==0)=1e-7;
m2(m2==0)=1e-7;
alpha = alpha(alpha<1e19);

dat = [zeros(size(alpha)),alpha./m2,    ones(size(alpha)),(alpha-m1)./m2,    alpha./m1,zeros(size(alpha)),   (alpha-m2)./m1,ones(size(alpha))];
dat(dat<0 | dat>1)= -1e20;
dat1 = zeros(size(x1,1),4);
for i = 1:length(alpha)
    j = find(dat(i,:)<-1e-19);
    j2 = j;
    j2(j<5) = j(j<5)-1; j2(j>4) = j(j>4)+1;
    tdat = dat(i,:);
    tdat([j j2])=[];
    dat1(i,:) = tdat;
    
end

imagesc(x,y,psi');    caxis([0 1]);
hold on
for i = 1:length(I)
%     plot(x(I(i)), y(J(i)), 'kx')
    plot(x(I(i))-dx/2+dx*dat1(i,[1 3]),y(J(i))-dy/2+dy*dat1(i,[2 4]),str,'linewidth',1.5);
end
% xlabel('x-axis'); ylabel('y-axis');
set(gca,'Ydir','Normal');
axis equal;
% colormap(parula);
% colorbar;
% for j = 2:N+3
%     plot([x(1),x(end)],[y(j) y(j)]-dy/2,'-','color',[0.9 0.9 0.9 .2])
% end
% for i = 2:M+3
%     plot([x(i) x(i)]-dx/2,[y(1),y(end)],'-','color',[0.9 0.9 0.9 .2])
% end

% plot(x(I),y(J),'ro')
hold off

