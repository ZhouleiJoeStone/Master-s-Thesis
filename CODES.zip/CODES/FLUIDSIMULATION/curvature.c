#include "mex.h"
#include "math.h"
#include "stdint.h"

double sc = 1e-8;
int sign(double x) {return ((x > 0) ? 1 : ((x < 0) ? -1 : 0));}
double slant(double x) {return ((x > 1) ? 1 : ((x < 0) ? 0 : x));}
double step(double x) {return ((x > 0) ? 1.0 : ((x < 0) ?  0.0 : 0.5));}
//double min(double a, double b) {return ((a > b) ? b : a);}
//double max(double a, double b) {return ((a > b) ? a : b);}

const int INSIDE = 0; // 0000
const int LEFT = 1;   // 0001
const int RIGHT = 2;  // 0010
const int BOTTOM = 4; // 0100
const int TOP = 8;    // 1000

int ComputeOutCode(double x, double y, double xmin, double xmax, double ymin, double ymax){
  int code;
	code = INSIDE;          // initialised as being inside of [[clip window]]
	if (x < xmin)           // to the left of clip window
		code |= LEFT;
	else if (x > xmax)      // to the right of clip window
		code |= RIGHT;
	if (y < ymin)           // below the clip window
		code |= BOTTOM;
	else if (y > ymax)      // above the clip window
		code |= TOP;
	return code;
}

int CohenSutherlandLineClip(double *x0, double *y0, double *x1, double *y1, double xmin, double xmax, double ymin, double ymax){

	int outcode0 = ComputeOutCode(*x0, *y0, xmin, xmax, ymin, ymax);
	int outcode1 = ComputeOutCode(*x1, *y1, xmin, xmax, ymin, ymax);
	int accept = 0;

	while (1) {
		if (!(outcode0 | outcode1)) {
			accept = 1;
			break;
		} else if (outcode0 & outcode1) {
			break;
		} else {
			double x, y;

			int outcodeOut = outcode0 ? outcode0 : outcode1;

			if (outcodeOut & TOP) {           // point is above the clip window
				x = *x0 + (*x1 - *x0) * (ymax - *y0) / (*y1 - *y0);
				y = ymax;
			} else if (outcodeOut & BOTTOM) { // point is below the clip window
				x = *x0 + (*x1 - *x0) * (ymin - *y0) / (*y1 - *y0);
				y = ymin;
			} else if (outcodeOut & RIGHT) {  // point is to the right of clip window
				y = *y0 + (*y1 - *y0) * (xmax - *x0) / (*x1 - *x0);
				x = xmax;
			} else if (outcodeOut & LEFT) {   // point is to the left of clip window
				y = *y0 + (*y1 - *y0) * (xmin - *x0) / (*x1 - *x0);
				x = xmin;
			}

			if (outcodeOut == outcode0) {
				*x0 = x;
				*y0 = y;
				outcode0 = ComputeOutCode(*x0, *y0, xmin, xmax, ymin, ymax);
			} else {
				*x1 = x;
				*y1 = y;
				outcode1 = ComputeOutCode(*x1, *y1, xmin, xmax, ymin, ymax);
			}
		}
	}
	return accept;
}

void curvature(int M, int N, double *psi, double *nx, double *ny, 
        double *alpha, double dx, double *cur, double *Lx, double *Ly){
    int i,j,m,n;
    for(j = 2; j < N+2; j++){
        for(i = 2; i < M+2; i++){
            int  ind = i + (M+4)*(j);
            double mx = nx[ind]; double my = ny[ind];
            int ig = ((i==2)||(i==(M+1)))||((j==2)||(j==(N+1)));
            if (alpha[ind]<1e19){
                double cell[3][7] = {0}; int dir, dir2, in, ic;
                if (fabs(mx)>=fabs(my)){
                    dir = sign(-mx); dir2 = sign(-my);
                    for (m = -1; m < 2; m++){
                        for (n = (ig?-2:-3); n < (ig?3:4); n++){
                            in = i+n + (M+4)*(j+m*dir2);
                            cell[m+1][n+3] = psi[in];
                        }
                    }
                }
                else{
                    dir = sign(-my); dir2 = sign(-mx);
                    for (m = -1; m < 2; m++){
                        for (n = (ig?-2:-3); n < (ig?3:4); n++){
                            in = i+m + (M+4)*(j+n*dir);
                            cell[m+1][n+3] = psi[in];
                        }
                    }
                }

                double H[3] = {0};
                for (m = 0; m < 3; m++){
                    for (n = 0; n < 7; n++){
                        H[m] += cell[m][n]*dx;
                    }
                }
                //H[1] = dx*max(cell[1][0]+cell[1][1]+cell[1][2]+cell[1][3],cell[1][3]+cell[1][4]+cell[1][5]+cell[1][6]);
                double h1x2 = (H[1]-H[0])/(dx)*(H[1]-H[0])/(dx);
                double den = pow(1.0+h1x2,1.5);
                double numer = -(H[0]-2*H[1]+H[2])/(dx*dx);
                double numer2 = -2.0*(H[0]-2*H[1]+H[2])*dx;
                double den2 = sqrt((dx*dx+(H[1]-H[0])*(H[1]-H[0]))*(dx*dx+(H[2]-H[1])*(H[2]-H[1]))*(4.0*dx*dx+(H[2]-H[0])*(H[2]-H[0])));
                numer = (H[2]-2*H[1] + H[0])/(dx*dx);
                double hx = (H[2] -  H[0])/(2.0*dx);
                den = pow(1+hx*hx,1.5);
                cur[ind] = min(1/(dx),fabs(numer/den))*sign(-numer/den);
                
                double sum = (H[0]+H[1]+H[2])/dx;
                //mexPrintf("cur: %f\t%f\n",cur[ind], sum);
                double weight = exp(-(1.0/40.0*pow(sum-21.0/2.0,2.0)));
                if (sum<(6) || sum>(15)) cur[ind] = 0.0*cur[ind];
//                 else mexPrintf("test: %f\n",sum);
                ///////////////
                /*double nrm = sqrt(mx*mx+my*my);
                double m1 = mx/nrm, m2 = my/nrm, a = (alpha[ind]-mx/2-my/2)/nrm;
                double x0 = a*m1+m2, y0 = a*m2-m1, x1 = a*m1-m2, y1 = a*m2+m1;
                if (isnan(x0)) printf("exists1\n");
                int accept = CohenSutherlandLineClip(&x0, &y0, &x1, &y1, -.5, .5, -.5, .5);
                Lx[ind] = fabs(x0-x1);
                Ly[ind] = fabs(y0-y1);*/
                ///////////////////
    
                /*if (0*(fabs(mx)>fabs(my))){
                    mexPrintf("%g %g\n",mx,my);
                    int dir3 = sign(-my), dir4 = sign(-mx);
                    for (m = -1; m < 2; m++){
                        for (n = -3; n < 4; n++){
                            mexPrintf("[%.2f,%.2f]\t",cell[m+1][n+3],psi[i+n*dir3 + (M+4)*(j+m*dir4)]);
                        }
                        mexPrintf("\n");
                    }
                    mexPrintf("Curve: %f\t%f\t%f\n",H[0],H[1],H[2]);
                    mexPrintf("%f\n",cur[ind]);
                    //goto breakout;
                }*/
                
                
                
                
            }
        }
    }
}


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* Macros for the ouput and input arguments */
    double *B, *Lx, *Ly, *U, *mxin,  *myin, *alpha, *psin, dx, dy, dt;
    int M, N, i, j, k, num;
    M = mxGetScalar(prhs[0]); /* Get the dimensions of A */
    N = mxGetScalar(prhs[1]);
    mxin = mxGetPr(prhs[2]);
    myin = mxGetPr(prhs[3]);
    psin = mxGetPr(prhs[4]);
    alpha = mxGetPr(prhs[5]);
    dx = mxGetScalar(prhs[6]);
    

    plhs[0] = mxCreateDoubleMatrix(M+4, N+4, mxREAL); /* Create the output matrix */
    plhs[1] = mxCreateDoubleMatrix(M+4, N+4, mxREAL); /* Create the output matrix */
    plhs[2] = mxCreateDoubleMatrix(M+4, N+4, mxREAL);
    B  = mxGetPr(plhs[0]);
    Lx = mxGetPr(plhs[1]);
    Ly = mxGetPr(plhs[2]);
    
    /***********************************************************
     *Begin Computation
     ***********************************************************/
    
    curvature(M,N,psin,mxin,myin,alpha,dx,B,Lx,Ly);
    
    /*nx and ny are not normal but sum vectors*/
    
    return;
}