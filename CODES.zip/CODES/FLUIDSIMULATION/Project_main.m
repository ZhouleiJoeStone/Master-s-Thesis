close all, clear all;
set(0,'defaultTextInterpreter','latex'); %trying to set the default
ph = {};
cmap = lines;
for Case = 1:3
    st = {':',':',':'};
    M = 64;
    N = M;
    dim = [0 1 0 1]/100;
    rho_liquid = 1000.0; %kg/m^3
    rho_gas    = 100.00; %kg/m^3
    mu_liquid = 8.9e-4; %N�s/m^2
    mu_gas    = 1.81e-5;%N�s/m^2
    surface_tension_coefficient = 0.07; %N/m
    dx = (dim(2)-dim(1))/M;
    dy = (dim(4)-dim(3))/N;
    h = dx;
    t = 0;
    k = 0; %iteration count
    dist = 1e-100*pi;
    x = linspace(dim(1)-3*dx/2,dim(2)+3*dx/2,M+4)+dist; %cell center locations
    y = linspace(dim(3)-3*dy/2,dim(4)+3*dx/2,N+4)+dist;
    xf = linspace(dim(1),dim(2),M+1)+dist; %wall locations
    yf = linspace(dim(3),dim(4),N+1)+dist;
    [X, Y] = meshgrid(x,y); X = X'; Y = Y'; %mesh Grid
    x = linspace(dim(1)-dx/2,dim(2)+dx/2,M+2)+dist; %cell center locations
    y = linspace(dim(3)-dy/2,dim(4)+dx/2,N+2)+dist;
    [XU, YU] = meshgrid(xf,y); XU = XU'; YU = YU';
    [XV, YV] = meshgrid(x,yf); XV = XV'; YV = YV';
    x = linspace(dim(1)-3*dx/2,dim(2)+3*dx/2,M+4)+dist; %cell center locations
    y = linspace(dim(3)-3*dy/2,dim(4)+3*dx/2,N+4)+dist; %bring it back
    
    BC3 = @(p,M,N) p([4 3 3:M+2 M+2 M+1],[4 3 3:N+2 N+2 N+1]);
    BC2 = @(p,M,N) p([2 2:M+1 M+1],[2 2:N+1 N+1]);
    MB1 = @(p)  p(2:end-1,2:end-1);
    BCu = @(u,M,N) [-u(1:M+1,2) u(1:M+1,2:N+1) -u(1:M+1,N+1)];
    BCv = @(v,M,N) [-v(2,1:N+1);v(2:M+1,1:N+1);-v(M+1,1:N+1)];
    
    psi = phitopsi(M,N,X,Y,dx,dy,X); %compute psi from phi
    psi = BC3(psi,M,N);
    area = sum(sum(psi))*dx*dx; % compute Area
    [mx, my, alpha] = PLIC(M,N,dx,psi,2); %compute mx my and alpha
    
    phi = zeros(M+2,N+2); phi2 = phi; div = zeros(M+2,N+2); %phi becomes pressure
    u =  -sin(pi*XU*100).^2.*sin(2*pi*YU*100)*1e-8;
    v =  sin(2*pi*XV*100).*sin(pi*YV*100).^2*1e-8;
    u = BCu(u,M,N);
    v = BCv(v,M,N);
    un = u*0;
    vn = v*0;
    time = [0 .06 0.09 0.12 0.15]; time(1)= 1e-8;
    ti = [];
    vol = [];
    
    subplot(1,2,1)
    for count = 1:size(time,2)
        while t < time(count)
            maxu = max(max(abs(u)));
            maxv = max(max(abs(v)));
            dtu = h/(2*maxu+maxv);
            dtv = h/(maxu+2*maxv);
            dtc = sqrt((rho_gas+rho_liquid)*dx^3/(4*pi*surface_tension_coefficient));
            dtp = 0.1*dx^2/(mu_gas/rho_gas);
            
            dt = min([0.01*pi 0.5*dtu 0.5*dtv dtc dtp time(count)-t]);
            
            %%%%%%%%%%%  VOF advection
            rho = psi*rho_liquid + (1-psi)*rho_gas;
            mu = psi*mu_liquid + (1-psi)*mu_gas;
            
            a1 = sum(sum(psi(3:end-2,3:end-2)))*dx*dy;
            if Case == 1
                psi = octovof(M,N,u,v,mx,my,alpha,psi,dy,dt);
                psi(alpha>1.5e19 & alpha<2.5e19)=1; psi(isnan(psi))=0;
            elseif Case == 2
                psi = lagrange_remap(M,N,u,v,mx,my,alpha,psi,dy,dt);
                psi(alpha>1.5e19 & alpha<2.5e19)=1; psi(isnan(psi))=0;
            elseif Case == 3
                psi = splitLagrange(M,N,u,mx,my,alpha,psi,dy,dt);
                psi(alpha>1.5e19 & alpha<2.5e19)=1; psi(isnan(psi))=0;
                [mx, my, alpha] = PLIC(M,N,dx,psi,2); %PLIC Recon
                mx = BC3(mx,M,N); my = BC3(my,M,N);
                mx([1 2 M+3 M+4],:) = -mx([1 2 M+3 M+4],:);
                my(:,[1 2 N+3 N+4]) = -my(:,[1 2 N+3 N+4]);
                
                psi = splitLagrange(M,N,v',my',mx',alpha',psi',dy,dt)';
                psi(alpha>1.5e19 & alpha<2.5e19)=1; psi(isnan(psi))=0;
            end
            
            a2 = sum(sum(psi(3:end-2,3:end-2)))*dx*dy;
            psi = BC3(psi,M,N);
            
            [mx, my, alpha] = PLIC(M,N,dx,psi,2); %PLIC Recon
            mx = BC3(mx,M,N); my = BC3(my,M,N);
            mx([1 2 M+3 M+4],:) = -mx([1 2 M+3 M+4],:);
            my(:,[1 2 N+3 N+4]) = -my(:,[1 2 N+3 N+4]);
            
            % surface Tension
            rhon = psi*rho_liquid + (1-psi)*rho_gas;
            [cur,lenx,leny] = curvature(M,N,mx,my,psi,alpha,dx);
            len = sqrt(lenx.^2 + leny.^2)*0;
            Tx = surface_tension_coefficient*mx./sqrt(mx.^2+my.^2).*cur; Tx(isnan(Tx)) = 0;
            Ty = surface_tension_coefficient*my./sqrt(mx.^2+my.^2).*cur; Ty(isnan(Ty)) = 0;
            
            %Precompute Advection
            m = psi(2:end-1,2:end-1)*mu_liquid + (1-psi(2:end-1,2:end-1))*mu_gas;
            r = rhon(2:end-1,2:end-1);
            
            %%%%%%%%%%   Momentum Advection
            i = 2:M; j = 2:N+1;
            gammax = 1+0*max(abs(u(i,j))*dt/dx,abs(v(i,j))*dt/dx);
            duudx = 0.25*((u(i+1,j)+u(i,j)).^2-(u(i,j)+u(i-1,j)).^2)/dx + ...
                0.25*gammax.*(abs(u(i+1,j)+u(i,j)).*(u(i,j)-u(i+1,j)) - ...
                abs(u(i,j)+u(i-1,j)).*(u(i-1,j)-u(i,j)))/dx;
            duvdy = 0.25*((u(i,j+1)+u(i,j)).*(v(i+1,j)+v(i,j))-...
                (u(i,j)+u(i,j-1)).*(v(i+1,j-1)+v(i,j-1)))/dy+...
                0.25*gammax.*((u(i,j)-u(i,j+1)).*abs(v(i+1,j)+v(i,j))-...
                (u(i,j-1)-u(i,j)).*abs(v(i+1,j-1)+v(i,j-1)))/dy;
            laplu = (u(i+1,j)-2*u(i,j)+u(i-1,j))/dx^2+(u(i,j+1)-2*u(i,j)+u(i,j-1))/dy^2;
            laplu = ((1/dx)*2.*(m(i+1,j).*(1/dx).*(u(i+1,j)-u(i,j)) - ...
                m(i,j).*(1./dx).*(u(i,j)-u(i-1,j)) ) ...
                +(1/dy)*( 0.25*(m(i,j)+m(i+1,j)+m(i+1,j+1)+m(i,j+1)).* ...
                ((1/dy).*(u(i,j+1)-u(i,j)) + (1./dx)*(v(i+1,j)-v(i,j)) ) - ...
                0.25*(m(i,j)+m(i+1,j)+m(i+1,j-1)+m(i,j-1)).* ...
                ((1/dy).*(u(i,j)-u(i,j-1))+ (1/dx)*(v(i+1,j-1)- v(i,j-1))) )...
                )./(0.5*(r(i+1,j)+r(i,j)) );
            tx = (0.5*(Tx(i+1,j+1)+Tx(i+2,j+1)));
            un(i,j) = u(i,j)+dt*( -duudx -duvdy + tx + ...
                laplu);%-10*exp(-t*100)*XU(i,j)./sqrt(XU(i,j).^2+YU(i,j).^2));
            
            i = 2:M+1; j = 2:N;
            gammay = 1+0*max(abs(u(i,j))*dt/dx,abs(v(i,j))*dt/dx);
            dvudx = 0.25*((u(i,j+1)+u(i,j)).*(v(i+1,j)+v(i,j))-...
                (u(i-1,j+1)+u(i-1,j)).*(v(i,j)+v(i-1,j)))/dx + ...
                0.25*gammay.*(abs(u(i,j+1)+u(i,j)).*(v(i,j)-v(i+1,j))-...
                abs(u(i-1,j+1)+u(i-1,j)).*(v(i-1,j)-v(i,j)))/dx;
            dvvdy = 0.25*((v(i,j+1)+v(i,j)).^2-(v(i,j)+v(i,j-1)).^2)/dy + ...
                0.25*gammay.*(abs(v(i,j+1)+v(i,j)).*(v(i,j)-v(i,j+1))-...
                abs(v(i,j)+v(i,j-1)).*(v(i,j-1)-v(i,j)))/dy;
            laplv = (v(i+1,j)-2*v(i,j)+v(i-1,j))/dx^2+(v(i,j+1)-2*v(i,j)+v(i,j-1))/dy^2;
            laplv = ((1/dx)*( 0.25*(m(i,j)+m(i+1,j)+m(i+1,j+1)+m(i,j+1)).* ...
                ((1/dy)*(u(i,j+1)-u(i,j)) + (1/dx)*(v(i+1,j)-v(i,j)) ) - ...
                0.25*(m(i,j)+m(i,j+1)+m(i-1,j+1)+m(i-1,j)).* ...
                ((1/dy)*(u(i-1,j+1)-u(i-1,j))+ (1/dx)*(v(i,j)- v(i-1,j))) )...
                +(1/dy)*2*(m(i,j+1).*(1/dy).*(v(i,j+1)-v(i,j)) - ...
                m(i,j).*(1/dy).*(v(i,j)-v(i,j-1)) ) ...
                )./(0.5*(r(i,j+1)+r(i,j)) );
            ty = (0.5*(Ty(i+1,j+1)+Ty(i+1,j+2)));
            vn(i,j)=v(i,j)+dt*(-dvudx - dvvdy + ty +...
                laplv-1);%exp(-t*100)*YV(i,j)./sqrt(YV(i,j).^2+XV(i,j).^2));
            un = BCu(un,M,N); vn = BCv(vn,M,N);
            
            
            i = 2:M+1;
            j = 2:N+1;
            %Pressure Computation
            div(i,j) = 1/dt*((un(i,j)-un(i-1,j))/dx+(vn(i,j)-vn(i,j-1))/dy);
            num = int32(zeros(M+2,N+2)); num(2:end-1,2:end-1) = int32(reshape(1:M*N,[M N]));
            [I,J,X,divergence,pressure] = pressuresolver(phi,div,MB1(rhon),num,dx);
            K = sparse([I (M*N)+1],[J (M*N)],[X 1]);
            phi(i,j) = reshape(K\[divergence;0],[M N]);
            phi = BC2(phi,M,N);
            
            
            %Velocity Correction
            i = 2:M; j = 2:N+1; % correct u-velocity
            u(i,j) = un(i,j) - dt/dx*(phi(i+1,j)-phi(i,j))./(rhon(i+1+1,j+1)+rhon(i+1,j+1));
            i = 2:M+1; j = 2:N; % correct v-velocity
            v(i,j) = vn(i,j) - dt/dy*(phi(i,j+1)-phi(i,j))./(rhon(i+1,j+1+1)+rhon(i+1,j+1));
            
            
            u = BCu(u,M,N); v = BCv(v,M,N);
            
            i = M/2; j = N/2; an1=(u(i,j)-u(i-1,j))/dx+(v(i,j)-v(i,j-1))/dy;
            
            t = t + dt;
            k = k + 1;
            ti(k) = t;
            vol(k) = sum(sum(psi(3:end-2,3:end-2)))*dx*dy/((dim(2)-dim(1))*(dim(4)-dim(3)));
            fprintf('t = %g\tdt = %g\tA = %g\tD = %g\n',t,dt,vol(k),an1);
            %%%%%%%%%  End Loop
        end
        [X, Y] = interface(M,N,mx,my,alpha,dx);
        ph{Case} = plot(X*100,Y*100,st{Case},'color',cmap(Case,:));
        set(gca,'TickLabelInterpreter', 'latex');
        [~,maxi] = max(X);
        if Case==1
            text((X(maxi)+.0001)*100,(Y(maxi)+.0003)*100,num2str(t,'$$t = %.2fs$$'),'interpreter','Latex')
        end
        %imagesc(x,y,psi')
        xlabel('x-axis (cm)','interpreter','Latex');
        ylabel('y-axis (cm)','interpreter','Latex');
        
        axis equal;
        axis(dim*100);set(gca,'Ydir','normal');
        hold on;
        drawnow;
        
    end
    subplot(1,2,2)
    hold on
    semilogy(ti,abs(vol-.15^2*pi),st{Case},'color',cmap(Case,:),'Linewidth',2)
    hold off
end
subplot(1,2,1)
legend([ph{1} ph{2} ph{3}],{'Unsplit Eulerial Advection','Unsplit Lagrangian Advection','Split Lagrangian Advection'},'Interpreter','latex','Location','NorthWest')
subplot(1,2,2)
legend({'Unsplit Eulerial Advection','Unsplit Lagrangian Advection','Split Lagrangian Advection'},'Interpreter','latex','Location','East')
set(gca,'YScale','Log')
set(gca,'TickLabelInterpreter', 'latex');
set(gcf,'Position',[680 563 978 415])
eval(['print -depsc2 -tiff -r300 -painters  ' num2str(M,'VERFS%i.eps')]);