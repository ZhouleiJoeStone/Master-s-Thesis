#include "mex.h"
#include "math.h"
#include "stdint.h"
#include "omp.h"


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    
    /* Macros for the ouput and input arguments */
    double *pin, *phi, *d2pin, *rhs, *rhoin, *I, *J, *X, dx,divi;
    int32_t *num;
    int M, N, i, j, k;
    pin = mxGetPr(prhs[0]);
    d2pin = mxGetPr(prhs[1]);
    rhoin =  mxGetPr(prhs[2]);
    num = mxGetData(prhs[3]);
    dx =  mxGetScalar(prhs[4]);
    M = mxGetM(prhs[0])-2; /* Get the dimensions of A */
    N = mxGetN(prhs[0])-2;
    int Mc = 8*M*N - 4*N - 4*M;
    plhs[0] = mxCreateDoubleMatrix(1, Mc, mxREAL); /* Create the output matrix */
    plhs[1] = mxCreateDoubleMatrix(1, Mc, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(1, Mc, mxREAL);
    plhs[4] = mxCreateDoubleMatrix(M*N, 1, mxREAL);
    plhs[3] = mxCreateDoubleMatrix(M*N, 1, mxREAL);
    I = mxGetPr(plhs[0]);
    J = mxGetPr(plhs[1]);
    X = mxGetPr(plhs[2]);
    phi = mxGetPr(plhs[4]);
    rhs = mxGetPr(plhs[3]);
    k = 0;
    for(j = 1; j < N+1; j++){
        for(i = 1; i < M+1; i++){
            phi[k] = pin[i + (M+2)*j];
            rhs[k] = d2pin[i + (M+2)*j];
            k++;
        }
    }
    /*********************************************************
     *Begin Computation
     **********************************************************/
    k = 0;
    for(j = 1; j < N+1; j++){
        for(i = 1; i < M+1; i++){
            if (num[i+1 + (M+2)*j]){
                divi = 1/(dx*dx*(rhoin[i + (M+2)*j]+rhoin[i+1 + (M+2)*j]));  
                I[k]=num[i + (M+2)*j];
                J[k]=num[i + (M+2)*j];
                X[k]=-1.0*divi;
                k++;
                I[k]=num[i + (M+2)*j];
                J[k]=num[i+1 + (M+2)*j];
                X[k]=1.0*divi;
                k++;
            }
            if (num[i-1 + (M+2)*j]){
                divi = 1/(dx*dx*(rhoin[i + (M+2)*j]+rhoin[i-1 + (M+2)*j]));
                I[k]=num[i + (M+2)*j];
                J[k]=num[i + (M+2)*j];
                X[k]=-1.0*divi;
                k++;
                I[k]=num[i + (M+2)*j];
                J[k]=num[i-1 + (M+2)*j];
                X[k]=1.0*divi;
                k++;
            }
            if (num[i + (M+2)*(j+1)]){
                divi = 1/(dx*dx*(rhoin[i + (M+2)*j]+rhoin[i + (M+2)*(j+1)]));
                I[k]=num[i + (M+2)*j];
                J[k]=num[i + (M+2)*j];
                X[k]=-1.0*divi;
                k++;
                I[k]=num[i + (M+2)*j];
                J[k]=num[i + (M+2)*(j+1)];
                X[k]=1.0*divi;
                k++;
            }
            if (num[i + (M+2)*(j-1)]){
                divi = 1/(dx*dx*(rhoin[i + (M+2)*j]+rhoin[i + (M+2)*(j-1)]));
                I[k]=num[i + (M+2)*j];
                J[k]=num[i + (M+2)*j];
                X[k]=-1.0*divi;
                k++;
                I[k]=num[i + (M+2)*j];
                J[k]=num[i + (M+2)*(j-1)];
                X[k]=1.0*divi;
                k++;
            }
        }
    }
    /*********************************************************
     *End Computation
     **********************************************************/
    return;
}