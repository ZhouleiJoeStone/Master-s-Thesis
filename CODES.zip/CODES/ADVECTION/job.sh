#!/bin/bash

#SBATCH --nodes=1
#SBATCH --ntasks=12
#SBATCH -J lastVOF
#SBATCH -t 1-00:00
##SBATCH -A aansari2
#SBATCH -o lastVOF.%j.out
#SBATCH -e lastVOF.%j.err
##SBATCH --mail-type=END,FAIL       # notifications for job done & fail
##SBATCH --mail-user=aansari2@asu.edu # send-to address

module load matlab/2018a

matlab -nodisplay  < runall.m
