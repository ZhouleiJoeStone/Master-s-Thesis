#include "mex.h"
#include "math.h"
#include "stdint.h"
#include <time.h>
#include "nmsimplex.h"
double thresh = 1e-8;
double sign(double x) {return ((x > 0) ? 1.0 : ((x < 0) ? -1.0 : 0.0));}
double step(double x) {return ((x > 0) ? 1.0 : ((x < 0) ?  0.0 : 0.5));}

double min(double a, double b) {return ((a > b) ? b : a);}
double max(double a, double b) {return ((a > b) ? a : b);}

int caseno; //Choice of Reconstruction
//1: FDM, 2: COM, 3: ELVIRA, 4: LVIRA
double pg[3][3]; //global variable
void constraints(double *x, size_t n){}
nmsimplex_data_t MinDat = {.ConstraintFcn=NULL ,.epsilon=/*DBL_EPSILON*/1e-6, .Iterations=20};

double alphacomp(double psi, double mx1, double my1){     
    double a = 0, m1, m2, psi1, chi, snrm, mx, my; //computing alpha for mx
    snrm = fabs(mx1)+fabs(my1);
    mx = mx1/snrm;
    my = my1/snrm;
    if ((psi<1.0e-12) || (psi>(1.0-1.0e-12))){
        a = 1.0e20;
    }
    else{
        m1 = min(fabs(mx),fabs(my));
        m2 = max(fabs(mx),fabs(my));
        psi1 = m1/(2.0*(1.0-m1));
        chi = min(psi,1.0-psi);
        if (chi<psi1)
            a = sqrt(2.0*m1*(1-m1)*chi);
        if ((chi>=psi1) && (chi<=.5))
            a = (1-m1)*chi+m1/2.0;
        if (psi>.5)
            a = 1.0-a;
    }
    return a;
}

double subalphacomp(double psi, double mx1, double my1){
    psi = 1.0 - psi;     
    double a = 0, m1, m2, psi1, chi, snrm, mx, my; //computing alpha for mx
    snrm = fabs(mx1)+fabs(my1);
    mx = mx1/snrm;
    my = my1/snrm;
    if ((psi<0) || (psi>(1.0))){
        a = 1.0e20;
    }
    else{
        m1 = min(fabs(mx),fabs(my));
        m2 = max(fabs(mx),fabs(my));
        psi1 = m1/(2.0*(1.0-m1));
        chi = min(psi,1.0-psi);
        if (chi<psi1)
            a = sqrt(2.0*m1*(1-m1)*chi);
        if ((chi>=psi1) && (chi<=.5))
            a = (1-m1)*chi+m1/2.0;
        if (psi>.5)
            a = 1.0-a;
        a = a + min(0,mx) + min(0,my);
        a = (a-0.5*(mx+my))/sqrt(mx*mx+my*my);
    }
    return a;
}

double areacomp(double a, double b, double c){
    //Compute Area of PLIC
    if (a==0||b==0){
        a+=1e-10;
        b+=1e-10;
    }
    double capcb = c*a*a + c*b*b;
    double hp = (a+b)/2.0;
    double hm = (a-b)/2.0;
    
    double cpp = capcb + hp;
    double cmp = capcb - hp;
    double cpm = capcb + hm;
    double cmm = capcb - hm;
    
    double area = 0.5+(cpp*cpp*sign(cpp) + cmp*cmp*sign(cmp) - cpm*cpm*sign(cpm) - cmm*cmm*sign(cmm))/(4.0*a*b);
    return area;
}

double findError(double t[]){
  int i,j; double sum=0, ps[3][3];
  double cost = cos(t[0]), sint = sin(t[0]);
  double a = subalphacomp(pg[1][1], cost, sint);
  for(j = -1; j <= 1; j++){
    for(i = -1; i <= 1; i++){
      if (!((i==0)&&(j==0)))
      ps[i+1][j+1] = areacomp(cost, sint, -a+j*sint+i*cost);
      else ps[1][1] = pg[1][1];
    }
  }
  for (i = 0; i < 3; i++){
    for (j = 0; j < 3; j++){
      sum+=pow(pg[i][j]-ps[i][j],2.0);
    }
  }
  return sum;
}

void normalvec(int M, int N,  double dx, double dy, double *p, 
        double *nx, double *ny, double *alpha){
    int i,j,m,n;
    
    
    for(j = 0; j < N+4; j++){
        for (i = 0; i < M+4; i++){
            int BC = (i==0) || (i==M+3) || (j==0) || (j==N+3);
            int BC2= (i==1) || (i==M+2) || (j==1) || (j==N+2);
            
            int ind = i + (M+4)*(j);
            if ((/*((mx[i][j]==0) && (my[i][j]==0)) ||*/ BC) && ((p[ind]<thresh) || (p[ind]>(1-thresh)))){
                nx[ind] = 0.0;
                ny[ind] = 0.0;
                alpha[ind] = 1e20;
            }else{
                for (m = -1; m < 2; m++){
                    for(n = -1; n < 2; n++){
                        pg[m+1][n+1] = p[i+m + (M+4)*(j+n)];
                    }
                }
                double mx1 = 0, my1 = 0;
                double G[6], D[6][2];
                
                switch (caseno)
                {
                    case 0: //Finite Difference Method
                        m = 1; n = 1;
                        mx1 = (pg[m+1][n-1]-pg[m-1][n-1]) +
                                2.0*(pg[m+1][n]-pg[m-1][n]) +
                                (pg[m+1][n+1]-pg[m-1][n+1]);
                        my1 = (pg[m-1][n+1]-pg[m-1][n-1]) +
                                2.0*(pg[m][n+1]-pg[m][n-1]) +
                                (pg[m+1][n+1]-pg[m+1][n-1]);
                        break;
                    case 1:  //Center Of Mass code
                        for(n = -1; n <= 1; n++){
                            for(m = -1; m <= 1; m++){
                                mx1 += pg[m+1][n+1]*((double)m);
                                my1 += pg[m+1][n+1]*((double)n);
                            }
                        }
                        break;
                    case 2: case 3:
                        //ELVIRA CODE
                        for(m = 0; m < 3; m++)
                            G[m] = pg[m][0]+pg[m][1]+pg[m][2];//vertical sum
                        for(m = 3; m < 6; m++)
                            G[m] = pg[0][m-3]+pg[1][m-3]+pg[2][m-3]; //hortizontal sum
                        for(m = 0; m < 6; m+=3){
                            D[m][m/3] = G[m+1]-G[m];
                            D[m+1][m/3] =(G[m+2]-G[m])*0.5;
                            D[m+2][m/3] = G[m+2]-G[m+1];
                        }
                        for (m = 0; m < 3; m++){
                            D[m][1] = sign(D[4][1]);
                            D[m+3][0] = sign(D[1][0]);
                        }
                        double minerror = 10; int index;  double var[1];
                        for(n = 0; n < 6; n++){
                            var[0] = atan2(D[n][1],D[n][0]);
                            double error = findError(var);
                            if(error < minerror){
                                minerror = error;
                                index = n;
                            }
                        }
                        mx1 = D[index][0];  my1 = D[index][1];
                        if (caseno == 3){ //LVIRA Code
                            var[0] = atan2(my1,mx1);
                            minerror = nmsimplex(&MinDat, findError, var, 1);
                            mx1 = cos(var[0]); my1 = sin(var[0]);
                        }
                        break;
                }
                double nrm = fabs(mx1)+fabs(my1);
                nx[ind] = mx1/nrm;
                ny[ind] = my1/nrm;
                alpha[ind] = alphacomp(1-p[ind],nx[ind],ny[ind]);
            }
            if ((p[ind]<1e-8) || (p[ind]>(1-1e-8))){
                nx[ind] = 0.0;
                ny[ind] = 0.0;
                alpha[ind] = 1e20;
            }
            alpha[ind] = alpha[ind] + min(0.0,nx[ind]) + min(0.0,ny[ind]); 
            double uthres = 1.0-thresh;
            if (!BC){
                int unif = (p[(i+1) + (M+4)*(j+1)]>uthres) && (p[(i) + (M+4)*(j+1)]>uthres) &&
                    (p[(i-1) + (M+4)*(j+1)]>uthres) && (p[ind+1]>uthres) &&
                    (p[ind]>uthres) && (p[ind-1]>uthres) &&
                    (p[(i+1) + (M+4)*(j-1)]>uthres) &&
                    (p[(i) + (M+4)*(j-1)]>uthres) && (p[(i-1) + (M+4)*(j-1)]>uthres);
                if (unif) alpha[ind] = 2e19;
            }
        }

    }
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* Macros for the ouput and input arguments */
    double *B,  *C, *D, *psin, dx, dy, dt;
    int M, N, i, j, k, num;
    M = mxGetScalar(prhs[0]); /* Get the dimensions of A */
    N = mxGetScalar(prhs[1]);
    dx =  mxGetScalar(prhs[2]);
    dy =  dx;

    psin = mxGetPr(prhs[3]);
    caseno = mxGetScalar(prhs[4]);
    
    plhs[0] = mxCreateDoubleMatrix(M+4, N+4, mxREAL); /* Create the output matrix */
    plhs[1] = mxCreateDoubleMatrix(M+4, N+4, mxREAL); /* Create the output matrix */
    plhs[2] = mxCreateDoubleMatrix(M+4, N+4, mxREAL); /* Create the output matrix */

    B = mxGetPr(plhs[0]);
    C =  mxGetPr(plhs[1]);
    D =  mxGetPr(plhs[2]);

    /***********************************************************
     *Begin Computation
     ***********************************************************/
    normalvec(M, N, dx, dy, psin, B, C, D);
    /*nx and ny are not normal but sum vectors*/
    
    /***********************************************************
     *End Computation
     ***********************************************************/
    return;
}