function [shapeError, volError, timeItTook] = advection3(trialPLICMethodadvectMethodShapeCase)
% function [shapeError, volError] = advection(PLICMethod,trial,advectMethod,shapeCase)
% PLICMethod: 1-2-3-4 = 'Finite Difference','Center of Mass','ELVIRA','LVIRA'
% trial: Resolution, 1 = 64, 2 = 128 ... 5 = 1024
% advectMethod: 1 = Euler, 2 = Lagrange
% shapeCase: 1 = zalezak, 2 = Deformation Field
if nargin==0
%     PLICMethod = 3; %PLICMethod: 1-2-3-4 = FDM, COM, ELVIRA, LVIRA
%     trial = 2; % Resolution, 1 = 64, 2 = 128 ... 5 = 1024
%     advectMethod = 2; %1 = Euler, 2 = Lagrange
%     shapeCase = 2; %1 = zalezak, 2 = Deformation Feild
trialPLICMethodadvectMethodShapeCase = 10+16;
end
[shapeCase,PLICMethod,trial] = ind2sub([2 4 5],trialPLICMethodadvectMethodShapeCase);
PLMT = {'Finite Difference','Center of Mass','ELVIRA','LVIRA'};
fprintf('Started %i %s\n',trialPLICMethodadvectMethodShapeCase, PLMT{PLICMethod});
M = 2^(trial+5);
N = M;
dim = [0 1 0 1]; dim2 = [0.25 0.75 0.5 1];

dx = (dim(2)-dim(1))/M;
dy = (dim(4)-dim(3))/N;
k = 0; %iteration count
t = 0;
if shapeCase == 1
    DT = 2*pi;
else
    DT = 2;
end
BC3 = @(p,M,N) p([4 3 3:M+2 M+2 M+1],[4 3 3:N+2 N+2 N+1]);
% Initialization
x = linspace(dim(1)-3*dx/2,dim(2)+3*dx/2,M+4); % cell center locations
y = linspace(dim(3)-3*dy/2,dim(4)+3*dx/2,N+4);
xf = linspace(dim(1),dim(2),M+1); % wall locations
yf = linspace(dim(3),dim(4),N+1);

[X, Y] = meshgrid(x,y); X = X'; Y = Y'; % mesh Grid
[XU, YU] = meshgrid(xf,y(2:end-1)); XU = XU'; YU = YU';
[XV, YV] = meshgrid(x(2:end-1),yf); XV = XV'; YV = YV';

psi = phitopsi(M,N,X,Y,dx,dy,shapeCase); %compute psi from phi
psi2  = psi;
if  shapeCase == 1
    ts = (exp(linspace(-pi/2+asin(.025/.15),3*pi/2-asin(.025/.15),M)*1i)*0.15 + 0.5 + 0.75*1i);
    ts = [0.525+.85*1i ts 0.475+.85*1i 0.525+.85*1i];
else
    ts = exp(2i*pi*(0:1/M:1))*0.15 + 0.5 + 0.75*1i;
end
[mx, my, alpha] = PLIC(M,N,dx,psi,PLICMethod-1); %compute mx my and alpha
ux = -sin(pi*XU).^2.*sin(2*pi*YU);
vy = sin(2*pi*XV).*sin(pi*YV).^2;
%%%completed initialization
tic;
while t < DT
    dt = min(.25*dx*3/pi,DT-t);
    if dt>(DT/2-t)
        if shapeCase~=1
        end
    end
    if shapeCase == 1
        u = (YU-0.5);
        v = -(XV-0.5);
		uk =u;vk=v;
    else
        u =  ux*cos(pi*(t)/DT);
        v =  vy*cos(pi*(t)/DT);
		uk =  ux*cos(pi*(t+dt)/DT);
        vk =  vy*cos(pi*(t+dt)/DT);
    end
    psi = ALE(M,N,u,v,mx,my,alpha,psi,dy,dt,uk,vk);
    psi(alpha>1.5e19 & alpha<2.5e19)=1; psi(isnan(psi))=0;
    %psi = BC3(psi,M,N);
    [mx, my, alpha] = PLIC(M,N,dx,psi,PLICMethod-1);


    parea = sum(sum(psi(3:M+2,3:N+2)))*dx*dy;
    t = t + dt;
    k = k + 1;
    %ti(k) = t;
    %pa(k) = parea;
    %fprintf("%i\t%.16f\n",k,parea)
    %mx = BC3(mx,M,N); my = BC3(my,M,N);
    %mx([1 2 M+3 M+4],:) = -mx([1 2 M+3 M+4],:);
    %my(:,[1 2 N+3 N+4]) = -my(:,[1 2 N+3 N+4]);
    if (mod(k,1000)==1 || t>=DT) && (trial >= 2)
        %[X, Y] = interface(M,N,mx,my,alpha,dx);
        %plot(X,Y,real(ts),imag(ts),'--')
        fprintf("%i\t%i\t\t%.16f\n",trialPLICMethodadvectMethodShapeCase,k,t);
        %drawnow;
    end
    
    if (t>=DT/2) && abs(DT/2-t)<dt && shapeCase==2
        %imagesc(x,y,(psi)')
        [X, Y] = interface(M,N,mx,my,alpha,dx);
        plot(X,Y,real(ts),imag(ts),'--')
        title(sprintf('Area = %e,\tt = %.4f',parea,t));
        axis equal; grid on;
        axis(dim);
        %fprintf('%f\n',ta);
        saveas(gcf,[pwd '/images/' sprintf('smd%i%i%i%i.fig',...
            shapeCase,4,PLICMethod,trial)]);

    end
end
timeItTook = toc;
shapeError = dx*dy*sum(abs(psi(:)-psi2(:)));
volError = dx*dy*abs(sum(psi(:))-sum(psi2(:)));
fileID = fopen('exp4.txt','a+');
fprintf(fileID,'%i %i %i %i %i\t%i\t%.16e\t%.16e\t%f\n',trialPLICMethodadvectMethodShapeCase,...
    PLICMethod,trial, 4 ,shapeCase,M,shapeError,volError,timeItTook);
fprintf('%i %i %i %i %i\t%i\t%.16e\t%.16e\t%f\n',trialPLICMethodadvectMethodShapeCase, ...
    PLICMethod,trial, 4 ,shapeCase,M,shapeError,volError,timeItTook);
[X, Y] = interface(M,N,mx,my,alpha,dx);
plot(X,Y,'-','linewidth',2); hold on; plot(real(ts),imag(ts),'--'); hold off
legend('Solution','Exact Solution')
title(sprintf('M = %i, Shape Error = %.4e, Volume Error = %.4e',M,shapeError,volError));
xlabel(PLMT{PLICMethod});
axis equal;
axis(dim2);
saveas(gcf,[pwd '/images/' sprintf('sf%i%i%i%i.fig',...
    shapeCase,4,PLICMethod,trial)]);
fclose(fileID);