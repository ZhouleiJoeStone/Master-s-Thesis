#include "mex.h"
#include "stdlib.h"
#include "stdio.h"
#include "math.h"
#include "stdint.h"

double sign(double x) {return ((x > 0) ? 1.0 : ((x < 0) ? -1.0 : 0.0));}
double step(double x) {return ((x > 0) ? 1.0 : ((x < 0) ?  0.0 : 0.5));}
double side(double x) {return ((x > 0) ? x : 0.0);}

double areacomp(double a, double b, double c){
    //Compute Area of PLIC
    if (a==0||b==0){
        a+=1e-10;
        b+=1e-10;
    }
    double capcb = c*a*a + c*b*b;
    double hp = (a+b)/2.0;
    double hm = (a-b)/2.0;
    
    double cpp = capcb + hp;
    double cmp = capcb - hp;
    double cpm = capcb + hm;
    double cmm = capcb - hm;
    
    double area = 0.5+(cpp*cpp*sign(cpp) + cmp*cmp*sign(cmp) - cpm*cpm*sign(cpm) - cmm*cmm*sign(cmm))/(4.0*a*b);
    return area;
}

double flux(double nx, double ny , double a , double scale, int dir){
    double norm = sqrt(nx*nx+ny*ny);
    nx/=norm; ny/=norm; a/=norm;
    a = a + dir*0.5*scale*nx - dir*0.5*nx;
    nx = nx*scale;

    norm = sqrt(nx*nx+ny*ny);
    nx/=norm; ny/=norm; a/=norm;
    return areacomp(nx,ny,a)*scale;
}


void fluxHorizontal(int M, int N, double *u, double *psi ,double *mx,
double *my, double *alpha, double dx, double dt, double *psi2){
    int32_t i,j, ind;
    int8_t shx, shy;
    for(j = 2; j < N+2; j++){
        for(i = 2; i < M+2; i++){
            ind = i + (M+4)*(j);
            int8_t condition1 = (alpha[i+(M+4)*(j)]>1.5e19)&&(alpha[i+(M+4)*(j)]<2.5e19);
            int8_t condition2 = psi[i+(M+4)*(j)]>1e-11;
            int8_t condition3 = 0;
            for (shx = -2; shx < 3; shx++){ 
                for (shy = -2; shy < 3; shy++){
                    condition3 = condition3||(alpha[i+shx+(M+4)*(j+shy)]<1e19);
                }
            }
            if (condition3 && condition2){                
                double uleft = u[i-2 + (M+1)*(j-1)]*dt/dx, uright = u[i-1 + (M+1)*(j-1)]*dt/dx;
                double nlen = 1.0 + uright - uleft;
                double scaleright = side(uright/nlen);
                double scaleleft  = side(-uleft/nlen);
                
                double nx = mx[ind], ny = my[ind], a = alpha[ind], f_right = 0, f_left = 0;
                a = a-(nx+ny)*0.5;
                nx*=-1; ny*=-1; a*=-1;
                if (alpha[ind]<1e19){
                    if (uright>0)
                        f_right = flux(nx, ny , a , scaleright, 1)*nlen;
                    if (uleft<0)
                        f_left  = flux(nx, ny , a , scaleleft ,-1)*nlen;
                }
                else if ((alpha[ind]>1e19) && (psi[ind]>0.5)){
                    f_right = scaleright*nlen;
                    f_left  = scaleleft*nlen;
                    
                }
                else{
                    f_right = 0;
                    f_left  = 0;
                }
                psi2[ind-1] += f_left;
                psi2[ind] += nlen*psi[ind] - f_left - f_right;
                psi2[ind+1] += f_right;
            }
        }
    }
    for(j = 2; j < N+2; j++){
        for(i = 2; i < M+2; i++){
            ind = i + (M+4)*(j);
            if ((alpha[ind]>1.5e19)&&(alpha[ind]<2.5e19))
                psi2[ind] = 1;
        }
    }
    
}


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* Macros for the ouput and input arguments */
    double *B, *U, *mxin,  *myin, *a1in, *psin, dx, dy, dt;
    int M, N;
    M = mxGetScalar(prhs[0]); /* Get the dimensions of A */
    N = mxGetScalar(prhs[1]);
    U    = mxGetPr(prhs[2]);
    mxin = mxGetPr(prhs[3]);
    myin = mxGetPr(prhs[4]);
    a1in = mxGetPr(prhs[5]);
    psin = mxGetPr(prhs[6]);
    dx = mxGetScalar(prhs[7]); dy = dx;
    dt = mxGetScalar(prhs[8]);

    plhs[0] = mxCreateDoubleMatrix(M+4, N+4, mxREAL); /* Create the output matrix */
    
    B = mxGetPr(plhs[0]);
    
    /***********************************************************
     *Begin Computation
     ***********************************************************/
    fluxHorizontal(M,N,U,psin,mxin,myin,a1in,dx,dt,B);

    /*nx and ny are not normal but sum vectors*/
    
    return;
}